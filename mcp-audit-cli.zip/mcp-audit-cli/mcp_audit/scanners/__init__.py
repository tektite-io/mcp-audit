"""
MCP Audit Scanners - Detection modules for various MCP configurations
"""
