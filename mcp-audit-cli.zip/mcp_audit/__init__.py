"""
MCP Audit - Discover and audit MCP configurations
"""

__version__ = "0.1.0"
